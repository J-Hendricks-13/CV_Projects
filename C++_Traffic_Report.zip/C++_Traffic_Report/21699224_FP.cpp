//21699224 Jawaad Hendricks
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <iomanip>   // For setting precision
#include <algorithm> // For STL algorithms
#include <stack>     // For stack container adapter
#include <queue>     // For queue container adapter
#include <iterator>  // For iterators
#include <numeric>   // For accumulate
#include <cctype>    // For toupper

using namespace std;

class TrafficReport
{
private:
//the use of maps in this Report 1 is using the vehcile type as our
//unique keys and the value will be that vehicle type count
// the map data structure will also be used as the base data structure or "Container"
//being used with Code containers such as Vector, Queue and Pair data structures
//that will act as an interface for us to interact with the data

    map<string, int> vehiclesPerDay;   // Date (YYYY-MM-DD) -> Vehicle Count
    map<string, int> vehicleTypeCount; // Vehicle Type -> Count
    int totalVehicles = 0;

    map<string, map<int, int>> hourlyTraffic; // Date -> Hour (0-23) -> Vehicle Count
    vector<int> speeds;                                 // All vehicle speeds

//Help functions to assist with string processing 
    string trim(const string &str) const
    {
        //the use of auto is usually used with iterators and intializing varibales
        //in this case we use it to intitialize using the substring ranges
        auto start = str.find_first_not_of(" \t");
        auto end = str.find_last_not_of(" \t");
        return (start == string::npos) ? "" : str.substr(start, end - start + 1);
    }

    string formatHourInterval(int hour) const
    {
        //string formatatting
        return to_string(hour) + ":00";
    }

public:
// Function to parse the traffic data from the file
    void parseTrafficData(const string &filename)
    {
        //Reads the data from the file using ifstream
        ifstream file(filename);
        if (!file.is_open())
        {
            cerr << "Error: Could not open the file \"" << filename << "\"!" << endl;
            return;
        }

        //getline is used with a delimeter to extract the data accordingly
        string line;
        while (getline(file, line))
        {
            stringstream ss(line);
            string timestamp, vehicleType, speedStr;

            getline(ss, timestamp, ';');
            getline(ss, vehicleType, ';');
            getline(ss, speedStr, ';');

            timestamp = trim(timestamp);
            vehicleType = trim(vehicleType);
            speedStr = trim(speedStr);

            if (timestamp.size() >= 16)
            {
                //string splitting
                string date = timestamp.substr(0, 10);
                string hourStr = timestamp.substr(11, 2);

                int hour = 0;
                try
                {
                    //stoi is used to convert string to integer
                    hour = stoi(hourStr);
                    if (hour < 0 || hour > 23)
                        throw out_of_range("Hour out of valid range");
                }
                catch (const exception &e)
                {
                    cout << "Warning: Invalid hour \"" << hourStr << "\" in timestamp \""
                         << timestamp << "\"! Skipping this record." << endl;
                    continue;
                }

                vehiclesPerDay[date]++;
                hourlyTraffic[date][hour]++;
            }
            else
            {
                cout << "Warning: Invalid timestamp format \"" << timestamp << "\" in the file!" << endl;
                continue;
            }

            totalVehicles++;

            if (!vehicleType.empty())
            {
                //transform allows us to apply the function toUpper to each of the elements given
                transform(vehicleType.begin(), vehicleType.end(), vehicleType.begin(),
                          [](unsigned char c)
                          { return toupper(c); });
                vehicleTypeCount[vehicleType]++;
            }
            else
            {
                cout << "Warning: Missing vehicle type in the file!" << endl;
            }

            if (!speedStr.empty())
            {
                try
                {
                    int speed = stoi(speedStr);
                    if (speed < 0)
                        throw out_of_range("Negative speed value");
                    //Vector operation to insert       
                    //Vectors support efficient insertion and deletion 
                    //of elements at the end using push_back() and pop_back(), respectively.                     
                    speeds.push_back(speed);
                }
                //exception handling
                catch (const exception &e)
                {
                    cout << "Warning: Invalid speed \"" << speedStr << "\" for vehicle type \""
                         << vehicleType << "\" on timestamp \"" << timestamp << "\"!" << endl;
                }
            }
            else
            {
                cout << "Warning: Missing speed in the file!" << endl;
            }
        }

        file.close();
    }

//Function for counting the daily vehicles
// the initial function produced was combined
//in my implementation I have chosen to separate the functions
//into 2 and then combine them in displayTrafficSummary
//reason for this is because we are wokring with 2 different maps
//and make the code more modular separates what we are dealing with

//Report 1 sub function 1
    void displayVehiclesPerDay() const
    {
        cout << "\nVehicle Count Per Day:" << endl;
        cout << "----------------------" << endl;

        int counter = 0;
        for (const auto &day : vehiclesPerDay)
        {
            cout << "Day " << ++counter << " (" << day.first << "): "
                 << day.second << " vehicles" << endl;
        }
    }
//Report 1 sub function 2
    void displayVehicleTypeDistribution() const
    {
        cout << "\nVehicle Type Distribution:" << endl;
        cout << "---------------------------" << endl;

        //Queue data structure being used with the pair data structure
        //the pair is the base data structure here
        //using key-value pairs
        //we are interacting with it in a FIFO system as an interface
        queue<pair<string, int>> typeQueue;

        for (const auto &type : vehicleTypeCount)
        {
            //insertion
            typeQueue.push(type);
        }

        while (!typeQueue.empty())
        {
            pair<string, int> currentType = typeQueue.front();
            
            //popping the elements
            typeQueue.pop();

            if (currentType.second > 0)
            {
                //String processing
                double percentage = (static_cast<double>(currentType.second) / totalVehicles) * 100;
                cout << "- " << currentType.first << ": " << currentType.second
                     << " (" << fixed << setprecision(2) << percentage << "%)" << endl;
            }
        }
    }

//Combine Report 1
    void displayTrafficSummary() const
    {
        if (totalVehicles == 0)
        {
            cout << "No vehicles recorded." << endl;
            return;
        }

        cout << "\nTraffic Summary Report:" << endl;
        cout << "-----------------------" << endl;
        cout << "Total vehicles: " << totalVehicles << endl;

        displayVehiclesPerDay();
        displayVehicleTypeDistribution();
    }

//Report 2 sub function 1
    void displayOverallPeakTraffic() const
    {
        int overallPeakCount = 0;
        string overallPeakTime;
        string overallPeakDate;

        //hourlyTraffic map structure
        //and data extraction from there
        for (const auto &dateEntry : hourlyTraffic)
        {
            for (const auto &hourEntry : dateEntry.second)
            {
                //access of the key-values
                if (hourEntry.second > overallPeakCount)
                {
                    overallPeakCount = hourEntry.second;
                    overallPeakDate = dateEntry.first;
                    overallPeakTime = formatHourInterval(hourEntry.first);
                }
            }
        }        
    }

//Report 2 sub function 2
    void displayPeakTrafficByDay() const
    {
        int counter = 0;        
        cout << "\nPeak traffic by day:" << endl;

        //map data structure and data extraction thereof
        for (const auto &dateEntry : hourlyTraffic)
        {
            int dailyPeakCount = 0;
            int dailyPeakHour = 0;

            for (const auto &hourEntry : dateEntry.second)
            {
                if (hourEntry.second > dailyPeakCount)
                {
                    //here we access the detail of the key-values                     
                    dailyPeakCount = hourEntry.second;
                    dailyPeakHour = hourEntry.first;
                }
            }

            cout << "Date: " << dateEntry.first << "   Day " << ++counter
                 << " - Peak Hour: " << formatHourInterval(dailyPeakHour)
                 << " with " << dailyPeakCount << " vehicles" << endl;                      
        }
    }
//Report 2 sub function 3
    void displayAverageSpeed() const
    {
        //Vector function to test count
        if (speeds.empty())
        {
            cout << "No speed data available." << endl;
            return;
        }
        //accumulate to sum up the elements in a range
        //in this case the vector
        //fixed is used for string formating
        //setprecision to display a certain amount of digits after decimal point
        double averageSpeed = static_cast<double>(accumulate(speeds.begin(), speeds.end(), 0)) / speeds.size();
        cout << "Average Speed of Vehicles: " << fixed << setprecision(2) << averageSpeed << " km/h" << endl;
    }

    double calculateAverageSpeed() const
    {
        if (speeds.empty())
        {
            return 0.0;
        }
        //divides the sum by speeds.size() 
        //which gives the number of elements in the vector
        //to give the average speed.
        return accumulate(speeds.begin(), speeds.end(), 0.0) / speeds.size();
    }

    map<string, int> categorizeSpeeds() const
    {
        //map data structure for the 3 levels of speed
        //used to display the information more so
        map<string, int> speedCategories = {{"Slow (0-30 km/h)", 0},
                                            {"Medium (31-60 km/h)", 0},
                                            {"Fast (61+ km/h)", 0}};

        //use of the vector to traverse the elements
        //and catergorize them accordingly
        for (const auto &speed : speeds)
        {
            if (speed >= 0 && speed <= 30)
            {
                //0-30 is slow
                speedCategories["Slow (0-30 km/h)"]++;
            }
            else if (speed >= 31 && speed <= 60)
            {
                //31- 60 is medium
                speedCategories["Medium (31-60 km/h)"]++;
            }
            else if (speed >= 61)
            {
                //higher than 61 is fast
                speedCategories["Fast (61+ km/h)"]++;
            }
        }
        //return the map of speedCategories
        return speedCategories;
    }

//Combine Report 3
    void displaySpeedAnalysisReport() const
    {
        cout << "\nSpeed Analysis Report:" << endl;
        cout << "----------------------" << endl;

        //Vector data structure
        if (speeds.empty())
        {
            cout << "No speed data available." << endl;
            return;
        }

        double averageSpeed = calculateAverageSpeed();
        cout << "Average speed: " << fixed << setprecision(2) << averageSpeed << " km/h" << endl;

        //map data structure for the speed catergories
        map<string, int> speedCategories = categorizeSpeeds();
        cout << "Speed distribution:" << endl;
        for (const auto &category : speedCategories)
        {
            cout << "- " << category.first << ": " << category.second << " vehicles" << endl;
        }
    }
};

int main()
{
    TrafficReport report;

    // Parsing the traffic data from the specified file
    report.parseTrafficData("C:\\Jawaad_C++\\C++_Traffic_Report\\trafficdata.txt");
   // C:\\Jawaad_C++\\C++_Traffic_Report\\trafficdata.txt
   // report.parseTrafficData("C:\\data\\trafficdata.txt");

    // Display the traffic summary report
    report.displayTrafficSummary();

    // Display peak traffic time
    report.displayOverallPeakTraffic();

    // Display peak traffic by day
    report.displayPeakTrafficByDay();

    // Display average speed of vehicles
    report.displaySpeedAnalysisReport();

    return 0;
}