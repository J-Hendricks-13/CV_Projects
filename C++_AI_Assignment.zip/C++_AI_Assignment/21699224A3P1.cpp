// Student Name: [Jawaad Hendricks]
// Student Number: [21699224]

// Question(s) asked to the AI tool:
// 1. Generate C++ code to implement Prim's algorithm for finding the Minimum Spanning Tree with a time complexity of O(n^2).
// 2. How can I read graph data from a text file and apply Prim's algorithm to find the MST?

#include <iostream>
#include <vector>
#include <limits.h>
#include <fstream>

using namespace std;

// Function to find the vertex with the minimum key value
// int minKey(vector<int>& key, vector<bool>& mstSet, int V) {
//     int min = INT_MAX, min_index;

//     for (int v = 0; v < V; v++)
//         if (mstSet[v] == false && key[v] < min)
//             min = key[v], min_index = v;

//     return min_index;
// }
int minKey(vector<int>& key, vector<bool>& mstSet, int V) {
    int min = INT_MAX, min_index;
    for (int v = 0; v < V; v++) {
        if (!mstSet[v] && key[v] < min) {
            min = key[v];
            min_index = v;
        }
    }
    return min_index;
}

// Function to print the constructed MST
// void printMST(vector<int>& parent, vector<vector<int>>& graph, int V) {
//     cout << "Minimum Spanning Tree using Prim's Algorithm:\n";
//     for (int i = 1; i < V; i++)
//         cout << parent[i] << " - " << i << "\t" << graph[i][parent[i]] << " \n";
// }

void printMST(vector<int>& parent, vector<vector<int>>& graph, int V) {
    cout << "Edge \tWeight\n";
    int total_weight = 0;
    for (int i = 1; i < V; i++) {
        cout << parent[i] << " - " << i << "\t" << graph[i][parent[i]] << " \n";
        total_weight += graph[i][parent[i]];
    }
    cout << "Total weight of MST: " << total_weight << endl;
}


// Function to construct and print MST
// void primMST(vector<vector<int>>& graph, int V) {
//     // Array to store constructed MST
//     vector<int> parent(V);

//     // Key values used to pick minimum weight edge in cut
//     vector<int> key(V, INT_MAX);

//     // To represent set of vertices included in MST
//     vector<bool> mstSet(V, false);

//     // Always include first 1st vertex in MST.
//     key[0] = 0; // Make key 0 so that this vertex is picked as first vertex
//     parent[0] = -1; // First node is always root of MST

//      // The MST will have V vertices
//     for (int count = 0; count < V - 1; count++) {
//         // Pick the minimum key vertex from the set of vertices not yet included in MST
//         int u = minKey(key, mstSet, V);

//         // Add the picked vertex to the MST Set
//         mstSet[u] = true;

//         // Update key value and parent index of the adjacent vertices of the picked vertex.
//         for (int v = 0; v < V; v++)
//             // graph[u][v] is non-zero only for adjacent vertices of u
//             // mstSet[v] is false for vertices not yet included in MST
//             // Update the key only if graph[u][v] is smaller than key[v]
//             if (graph[u][v] && mstSet[v] == false && graph[u][v] < key[v])
//                 parent[v] = u, key[v] = graph[u][v];
//     }
//     // print the constructed MST
//     printMST(parent, graph, V);
// }
void primMST(vector<vector<int>>& graph, int V) {
    vector<int> parent(V);
    vector<int> key(V, INT_MAX);
    vector<bool> mstSet(V, false);

    key[0] = 0;
    parent[0] = -1;

    for (int count = 0; count < V - 1; count++) {
        int u = minKey(key, mstSet, V);
        mstSet[u] = true;

        for (int v = 0; v < V; v++) {
            if (graph[u][v] && !mstSet[v] && graph[u][v] < key[v]) {
                parent[v] = u;
                key[v] = graph[u][v];
            }
        }
    }

    printMST(parent, graph, V);
}

// int main() {
//     // Reading graph data from a file
//     ifstream file("C:\\Jawaad_C++\\GrahpAssignment\\fiberdata.txt");
//   //  C:\\Jawaad_C++\GrahpAssignment\\fiberdata.txt
//     //C:\\Jawaad_C++\\msys64\\GrahpAssignment\\tes2.cpp
//     // ifstream inputFile("C:\\Jawaad_C++\\21699224_J_Hendricks\\BrowserHistory.txt");

//     // Update 1: Check if the file was opened successfully
//     if (!file) {
//         cerr << "Unable to open file fiberdata.txt";
//         exit(1); // Terminate the program
//     }

//  //   C:\Jawaad_C++\GrahpAssignment

//     int V, E;
//     file >> V >> E;

//     // Update 2: Initializing the adjacency matrix
//     //vector<vector<int>> graph(V, vector<int>(V, 0));

//     std::vector<std::vector<int>> graph(V, std::vector<int>(V, 0));  //

//     int u, v, weight = 0;
//     // Reading the edge data
//     for (int i = 0; i < E; i++) {
//         file >> u >> v >> weight;
//         graph[u][v] = weight;
//         graph[v][u] = weight; // Since the graph is undirected
//    // cout << i << endl;
//     }

//     file.close(); // Close the file

//     // Run Prim's algorithm
//     primMST(graph, V);

//     return 0;
// }
int main() {
    ifstream file("C:\\Jawaad_C++\\C++_AI_Assignment\\fiberdata.txt");
    
    //ifstream file("c:\\data\\fiberdata.txt");

    if (!file) {
        cerr << "Unable to open file: c:\\data\\fiberdata.txt" << endl;
        return 1;
    }

    int V, E;
    file >> V >> E;

    vector<vector<int>> graph(V + 1, vector<int>(V + 1, 0));

    int u, v, weight;
    for (int i = 0; i < E; i++) {
        file >> u >> v >> weight;
        graph[u][v] = weight;
        graph[v][u] = weight;
    }

    file.close();

    primMST(graph, V + 1);

    return 0;
}
//As part of the major adjustments, 
//fixing a segmentation fault related to the file reading of the graph construction
//adjusting the V+1 value: vector<vector<int>> graph(V + 1, vector<int>(V + 1, 0));
//to fix this
//the commented code before each function is my v1 base after 
//adjustments were made with AI assistance this was the final product.